export const GUEST_UID = 123;
